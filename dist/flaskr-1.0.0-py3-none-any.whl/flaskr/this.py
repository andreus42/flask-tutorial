for number in range(1, 99):
    print(number)
    for letter in range('a', 'z'):
        print(letter)
